/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

declare global {
  interface Window {
    deferredPrompt: any;
  }
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  window.deferredPrompt = e;
});

import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, loginWithGoogle, db, logout } from './lib/firebase';
import { setDoc, doc, getDoc, collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import './lib/i18n';
import toast, { Toaster } from 'react-hot-toast';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Tenants } from './pages/Tenants';
import { TenantDetail } from './pages/TenantDetail';
import { Payments } from './pages/Payments';
import { Maintenance } from './pages/Maintenance';
import { Expenses } from './pages/Expenses';
import { Calendar } from './pages/Calendar';
import { Properties } from './pages/Properties';
import { PropertyDetail } from './pages/PropertyDetail';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { PublicPay } from './pages/PublicPay';
import { Building2, LogIn, UserPlus, CheckCircle2 } from 'lucide-react';
import { Logo } from './components/Logo';

import { sendPasswordResetEmail } from 'firebase/auth';

function LoginForm({ onSuccess }: { onSuccess: () => void }) {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const res = await loginWithGoogle();
      if (res && res.user) {
         const u = res.user;
         const userDoc = await getDoc(doc(db, 'users', u.uid));
         if (!userDoc.exists()) {
             await setDoc(doc(db, 'users', u.uid), {
               name: u.displayName || 'Utilisateur',
               phone: '',
               email: u.email,
               googleEmail: u.email,
               createdAt: new Date().toISOString()
             });
         }
         
         // Bonus: Login history
         try {
           await addDoc(collection(db, 'users', u.uid, 'loginHistory'), {
             timestamp: new Date().toISOString(),
             method: 'google',
             userAgent: navigator.userAgent
           });
           toast.success("Nouvelle connexion détectée sur votre compte.", { position: 'bottom-center' });
         } catch (err) {}
         
         onSuccess();
      }
    } catch (e: any) {
        if (e.code === 'auth/popup-closed-by-user' || e.code === 'auth/cancelled-popup-request') {
          toast.error("Connexion Google annulée. Ouvrez l'application dans un NOUVEL ONGLET si la fenêtre ne s'ouvre pas.");
        } else if (e.code === 'auth/popup-blocked') {
          toast.error("Fenêtre bloquée. Veuillez ouvrir l'application dans un nouvel onglet ou autoriser les pop-ups.");
        } else if (e.code === 'auth/unauthorized-domain') {
          toast.error("Domaine non autorisé. Ajoutez cette URL dans la console Firebase (Authentication > Settings).");
        } else {
          toast.error(`Erreur Google: ${e.message || "Impossible de se connecter"}`);
        }
        console.error("Google login error", e);
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
         <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Bienvenue</h2>
         <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Connectez-vous pour accéder à votre espace de gestion.</p>
      </div>
      
      <button
        disabled={loading}
        onClick={handleGoogleLogin}
        className="w-full flex items-center justify-center gap-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-white py-3 px-4 rounded-xl font-medium transition-all shadow-sm hover:shadow-md disabled:opacity-50"
      >
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
        Continuer avec Google
      </button>
      <p className="text-xs text-center text-gray-500 mt-2">
        Utilisez votre compte Google pour une connexion rapide et sécurisée.
      </p>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        
        // Let's verify authorization here for persistent sessions
        // Timeout to avoid blocking UI for 10s if offline
        try {
          const userDocPromise = getDoc(doc(db, 'users', currentUser.uid));
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('timeout')), 3000)
          );
          
          const userDoc = await Promise.race([userDocPromise, timeoutPromise]) as any;
          if (userDoc && userDoc.exists && userDoc.exists()) {
            setIsAuthorized(true);
          } else {
            setIsAuthorized(false);
          }
        } catch (error: any) {
          if (error.message !== 'timeout') {
            // Ignore offline network errors from console to avoid noise
          }
          setIsAuthorized(true);
        }
        
      } else {
        setUser(null);
        setIsAuthorized(false);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 transition-colors">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user || !isAuthorized) {
    if (window.location.pathname.startsWith('/pay')) {
      return (
        <BrowserRouter>
          <Routes>
            <Route path="/pay" element={<PublicPay />} />
            <Route path="/pay/:tenantId" element={<PublicPay />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      );
    }

    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900 p-4 transition-colors">
        <Toaster />
        <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-xl max-w-md w-full text-center space-y-6 transition-colors">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Logo className="w-20 h-20" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">ImmoGest Kinshasa</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Gérez vos locataires et loyers facilement.</p>
          </div>
          
          <LoginForm onSuccess={() => setIsAuthorized(true)} />
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Toaster />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="properties" element={<Properties />} />
          <Route path="properties/:id" element={<PropertyDetail />} />
          <Route path="calendar" element={<Calendar />} />
          <Route path="tenants" element={<Tenants />} />
          <Route path="tenants/:id" element={<TenantDetail />} />
          <Route path="payments" element={<Payments />} />
          <Route path="expenses" element={<Expenses />} />
          <Route path="maintenance" element={<Maintenance />} />
          <Route path="reports" element={<Reports />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
        <Route path="/pay/:tenantId" element={<PublicPay />} />
      </Routes>
    </BrowserRouter>
  );
}
